import cv2 as cv
import numpy as np


def nothing(x):
    pass



cv.namedWindow("result", cv.WINDOW_NORMAL)

cv.createTrackbar("H LOWER", "result", 0, 179, nothing)
cv.createTrackbar("H UPPER", "result", 179, 179, nothing)

cv.createTrackbar("S LOWER", "result", 0, 255, nothing)
cv.createTrackbar("S UPPER", "result", 255, 255, nothing)

cv.createTrackbar("V LOWER", "result", 0, 255, nothing)
cv.createTrackbar("V UPPER", "result", 255, 255, nothing)


cap = cv.VideoCapture(0)

if not cap.isOpened():
    print("Kamera acilamadi.")
    exit()
cv.imshow("result", np.zeros((2,2), np.uint8))
cv.waitKey(200)


while True:
    ok, frame = cap.read()
    if not ok:
        break


    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    h_lower = cv.getTrackbarPos("H LOWER", "result")
    h_upper = cv.getTrackbarPos("H UPPER", "result")

    s_lower = cv.getTrackbarPos("S LOWER", "result")
    s_upper = cv.getTrackbarPos("S UPPER", "result")

    v_lower = cv.getTrackbarPos("V LOWER", "result")
    v_upper = cv.getTrackbarPos("V UPPER", "result")
    
    if h_upper < h_lower: h_upper = h_lower
    if s_upper < s_lower: s_upper = s_lower
    if v_upper < v_lower: v_upper = v_lower
    
    lower = (h_lower, s_lower, v_lower)
    upper = (h_upper, s_upper, v_upper)


    mask = cv.inRange(hsv, lower, upper)
    result = cv.bitwise_and(frame, frame, mask=mask)
    cv.imshow("result", result)
    if cv.waitKey(1) & 0xFF == 27: break
cap.release()    
cv.destroyAllWindows()
#trackbarları oluşturduktan sonra gettrackbar yapınca sanırım pencere açılamadan değer almaya çalışıyor
#o yüzden null tarzı hata alıyorum ilk iki uygulamada da olmuştu ama bir şekilde çözdüm bu uygulamada halledemedim
#hata alıyorum ama trackbar çalışıyor