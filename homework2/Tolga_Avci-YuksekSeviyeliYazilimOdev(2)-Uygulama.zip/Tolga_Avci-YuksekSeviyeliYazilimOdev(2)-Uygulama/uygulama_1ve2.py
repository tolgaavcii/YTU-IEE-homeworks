import cv2 as cv
import numpy as np

def nothing(x):
    pass

img = cv.imread("uygulama.jpeg")
if img is None:
    print("Dosya yuklenemedi.")
    exit()
rgb_img = cv.cvtColor(img, cv.COLOR_BGR2RGB)

r, g, b = cv.split(rgb_img)

r_min = r.min()
r_max = r.max()

g_min = g.min()
g_max = g.max()

b_min = b.min()
b_max = b.max()

#negatif değerlerin dönebilmesi için float çevirdim
r = r.astype(np.float32)
g = g.astype(np.float32)
b = b.astype(np.float32)

r_new = ((r - r_min) * (240 - r_min) / (r_max - r_min)) + 10
g_new = ((g - g_min) * (240 - g_min) / (g_max - g_min)) + 10
b_new = ((b - b_min) * (240 - b_min) / (b_max - b_min)) + 10

r_new = np.clip(r_new, 0, 255).astype('uint8')
g_new = np.clip(g_new, 0, 255).astype('uint8')
b_new = np.clip(b_new, 0, 255).astype('uint8')

rgb_new_img = cv.merge((r_new, g_new, b_new))

new_bgr_img = cv.cvtColor(rgb_new_img, cv.COLOR_RGB2BGR)

hsv = cv.cvtColor(new_bgr_img, cv.COLOR_BGR2HSV)


cv.namedWindow("Controls", cv.WINDOW_NORMAL)

cv.createTrackbar("H LOWER", "Controls", 0, 179, nothing)
cv.createTrackbar("H UPPER", "Controls", 179, 179, nothing)

cv.createTrackbar("S LOWER", "Controls", 0, 255, nothing)
cv.createTrackbar("S UPPER", "Controls", 255, 255, nothing)

cv.createTrackbar("V LOWER", "Controls", 0, 255, nothing)
cv.createTrackbar("V UPPER", "Controls", 255, 255, nothing)


while True:
    if cv.getWindowProperty("Controls", cv.WND_PROP_VISIBLE) <= 0:
        break
    h_lower = cv.getTrackbarPos("H LOWER", "Controls")
    h_upper = cv.getTrackbarPos("H UPPER", "Controls")

    s_lower = cv.getTrackbarPos("S LOWER", "Controls")
    s_upper = cv.getTrackbarPos("S UPPER", "Controls")

    v_lower = cv.getTrackbarPos("V LOWER", "Controls")
    v_upper = cv.getTrackbarPos("V UPPER", "Controls")
    
    if h_upper < h_lower: h_upper = h_lower
    if s_upper < s_lower: s_upper = s_lower
    if v_upper < v_lower: v_upper = v_lower

    lower = (h_lower, s_lower, v_lower)
    upper = (h_upper, s_upper, v_upper)


    mask = cv.inRange(hsv, lower, upper)
    result = cv.bitwise_and(new_bgr_img, new_bgr_img, mask=mask)
    #cv.imshow("mask", mask)
    cv.imshow("result", result)
    if cv.waitKey(1) & 0xFF == 27:
        break
    

#kendim analiz ederek bulduğum değerler
# h lower = 116 , h upper 179
# s lower = 0 , s upper 114
# v lower = 99 , v upper 154

lower = (116, 0 ,99)
upper =(179, 114, 154)
new_mask = cv.inRange(hsv, lower, upper)

contours, hierarchy = cv.findContours(new_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
c = max(contours, key=cv.contourArea)
x, y, w, h = cv.boundingRect(c)
copy = new_bgr_img.copy()
cv.rectangle(copy, (x, y), (x+w, y+h), (0,255,0), 2)
cv.putText(copy, "Balik", (x, max(0, y-10)), cv.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 2)

cv.imwrite("Balik_tespit.png", copy)
cv.imshow("result", copy)
cv.waitKey(0)
cv.destroyAllWindows()
