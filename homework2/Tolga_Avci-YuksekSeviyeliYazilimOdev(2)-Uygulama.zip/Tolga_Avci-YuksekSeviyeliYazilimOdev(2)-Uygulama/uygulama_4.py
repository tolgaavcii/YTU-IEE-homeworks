import cv2 as cv
import matplotlib.pyplot as plt


img = cv.imread("overexpos.jpg")
if img is None:
    print("Gorsel yuklenemedi.")



gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

equalized = cv.equalizeHist(gray)

hist = cv.calcHist([gray], [0], None, [256], [0,256])
eq_hist = cv.calcHist([equalized], [0], None, [256], [0,256])




b, g, r = cv.split(img)

eq_b = cv.equalizeHist(b)
eq_g = cv.equalizeHist(g)
eq_r = cv.equalizeHist(r)

equalized_bgr = cv.merge((eq_b, eq_g, eq_r))

b_hist = cv.calcHist([b], [0], None, [256], [0, 256])
eq_b_hist = cv.calcHist([eq_b], [0], None, [256], [0, 256])

g_hist = cv.calcHist([g], [0], None, [256], [0, 256])
eq_g_hist = cv.calcHist([eq_g], [0], None, [256], [0, 256])

r_hist = cv.calcHist([r], [0], None, [256], [0, 256])
eq_r_hist = cv.calcHist([eq_r], [0], None, [256], [0, 256])


cv.imshow("Original", img)
cv.imshow("Gray Equalized", equalized)
cv.imshow("kanal kanal eşitlenmiş", equalized_bgr)




plt.figure(figsize=(8,4))
plt.plot(hist,    label='Orijinal')
plt.plot(eq_hist, label='Eşitlenmiş')
plt.title("Histogram Karşılaştırması")
plt.xlabel("Piksel Parlaklık Değeri (0–255)")
plt.ylabel("Piksel Sayısı")
plt.xlim([0, 255])
plt.legend()
plt.show()


plt.figure(figsize=(12,6))

plt.subplot(1,3,1)
plt.plot(b_hist, color='b', label='Orijinal B')
plt.plot(eq_b_hist, color='c', label='Eşitlenmiş B')
plt.legend(); plt.xlim([0,256]); plt.title("Mavi Kanal")

plt.subplot(1,3,2)
plt.plot(g_hist, color='g', label='Orijinal G')
plt.plot(eq_g_hist, color='lime', label='Eşitlenmiş G')
plt.legend(); plt.xlim([0,256]); plt.title("Yeşil Kanal")

plt.subplot(1,3,3)
plt.plot(r_hist, color='r', label='Orijinal R')
plt.plot(eq_r_hist, color='m', label='Eşitlenmiş R')
plt.legend(); plt.xlim([0,256]); plt.title("Kırmızı Kanal")

plt.tight_layout()
plt.show()

cv.waitKey(0)
cv.destroyAllWindows()

