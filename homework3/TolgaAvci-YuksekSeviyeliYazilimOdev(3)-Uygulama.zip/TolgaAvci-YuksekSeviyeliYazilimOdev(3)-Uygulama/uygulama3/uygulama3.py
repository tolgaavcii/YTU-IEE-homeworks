import cv2 as cv

img = cv.imread("texts.png")
if img is None:
    print("Dosya yuklenemedi")
    exit()

gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

_, thresholded = cv.threshold(gray, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)


kernel = cv.getStructuringElement(cv.MORPH_RECT, (5,3))
dilated = cv.dilate(thresholded, kernel, iterations=1)

cntrs, _ = cv.findContours(dilated, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

text_count = 0
for c in cntrs:
    x, y, w, h = cv.boundingRect(c)
    if w*h > 50:
        cv.rectangle(img, (x, y), (x+w, y+h), (0,255,0), 2)
        text_count += 1
cv.putText(img, f"Text count: {text_count}", (10,30),
           cv.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2)
        
cv.imshow("counted_texts", img)
cv.imwrite("counted_texts.png", img)
cv.waitKey(0)
cv.destroyAllWindows()