import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

img = cv.imread("gizli_gorev.png")

if img is None:
    print("Dosya yuklenemedi.")
    exit()

print(img.shape)

b, g, r = cv.split(img)

plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
plt.hist(b.ravel(), 256, [0,256], color='b')
plt.title("Blue Channel")

plt.subplot(1,3,2)
plt.hist(g.ravel(), 256, [0,256], color='g')
plt.title("Green Channel")

plt.subplot(1,3,3)
plt.hist(r.ravel(), 256, [0,256], color='r')
plt.title("Red Channel")

plt.tight_layout()
plt.show()

cv.waitKey(0)
cv.destroyAllWindows()