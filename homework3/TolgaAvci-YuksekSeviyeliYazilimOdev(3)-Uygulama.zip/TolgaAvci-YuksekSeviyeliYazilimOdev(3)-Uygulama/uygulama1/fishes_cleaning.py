import cv2 as cv
import numpy as np

img = cv.imread("fishes.jpg")
if img is None:
    print("Görsel açılamadı.")
    exit()

# Gürültü azaltma
blurred = cv.GaussianBlur(img, (5,5), 0)
hsv_img = cv.cvtColor(blurred, cv.COLOR_BGR2HSV)

#trackbar ile bulduğum aralık
lower = (55, 137, 0)
upper = (121, 255, 193)

#morfolojik işlemler
kernel = cv.getStructuringElement(cv.MORPH_RECT, (3,3))
mask = cv.inRange(hsv_img, lower, upper)
mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)
mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)

cnts, _ = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)


output = img.copy()


for c in cnts:
    area = cv.contourArea(c)
    if area < 300:
        continue
    
    x, y, w, h = cv.boundingRect(c)

    
    if area > 8000:
        text_count = "2 balik"
    else:
        text_count = "1 balik"
   

    color_mask = np.zeros(mask.shape, dtype="uint8")
    cv.drawContours(color_mask, [c], -1, 255, -1)

    mean_val = cv.mean(hsv_img, mask=color_mask)
    hue = mean_val[0]

    #Renk sınıflandırma
    if hue < 10 or hue > 160:
        renk = "Kirmizi"
    elif hue < 30:
        renk = "Sari"
    elif hue < 85:
        renk = "Yeşil"
    elif hue < 130:
        renk = "Mavi"
    else:
        renk = "Mor"

    cv.rectangle(output, (x, y), (x+w, y+h), (0,255,0), 2)
    cv.putText(output, f"{text_count}, {renk}", (x, y-10),
               cv.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 2)

cv.imshow("mask", mask)
cv.imshow("baliklar", output)
cv.imwrite("detected_fishes.jpg", output)
cv.waitKey(0)
cv.destroyAllWindows()
