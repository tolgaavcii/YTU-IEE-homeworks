import cv2 as cv
import numpy as np

img = cv.imread("gizli_gorev.png")
if img is None:
    print("Fotograf acilamadi.")
    exit()

gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

__, thresholded = cv.threshold(gray, 1, 255, cv.THRESH_BINARY)

cv.imshow("thresholded", thresholded)

cv.waitKey(0)
cv.destroyAllWindows()