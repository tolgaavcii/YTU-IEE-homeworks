import cv2 as cv
import numpy as np


img = np.zeros((300, 300), dtype="uint8")

circle = np.zeros_like(img)
cv.circle(circle, (150,150), 150, 255, -1)

square = np.zeros_like(img)
cv.rectangle(square, (25,25), (275,275), 255, -1)

triangle1 = np.zeros_like(img)
coordinats1 = np.array([[100,150],[50,250],[150,250]], np.int32)
cv.fillPoly(triangle1, [coordinats1], 255)

triangle2 = np.zeros_like(img)
coordinats2 = np.array([[200,150],[250,250],[150,250]], np.int32)
cv.fillPoly(triangle2, [coordinats2], 255)


U = cv.bitwise_or(circle, square)
T = cv.bitwise_or(triangle1, triangle2)
final = cv.bitwise_and(U, cv.bitwise_not(T))

cv.imshow("my_and", final)
cv.waitKey(0)
cv.destroyAllWindows()
