class Item:
    def __init__(self,barcodeNo, itemName, price ,count):
        self.barcodeNo=barcodeNo
        self.itemName=itemName
        self.price= price
        self.count=count
    
    def getPrice(self):
        return self.price
    
    def increaseCount(self,amount):
        item.count+=amount
        