from item import Item
from basket import Basket

basket = Basket(1)

while True:
    print("       MENÜ      ")
    print("1-Ürün Ekle:")
    print("2-Toplam Fiyat:")
    print("3-Sepettikleri Görüntüle:")
    print("4-Çıkış.")

    try:
        seçim=int(input("Seçiminizi giriniz(1-4):"))
    except:
        print("Lütfen sayı giriniz.")
        continue

    if(seçim < 1 or seçim > 4):
        print("Sayınızı 1 ile 4 arasında seçiniz.")
        continue
    if seçim == 1:
        barcodeNo = input("Ürün Barkodu: ")
        name = input("Ürün İsmi: ")
        price = float(input("Ürün Fiyatı: "))
        count = int(input("Ürün Stok Miktarı: "))

        item=Item(barcodeNo,name,price,count)
        basket.addItem(item)
    elif seçim == 2:
        totalprice = basket.calculateTotalPrice()
        print(f"Sepet Toplam Fiyatı: {totalprice}")


    elif seçim == 3:
        basket.basketInfo()
        
    elif seçim == 4:
        print("Programdan çıkılıyor.")
        break