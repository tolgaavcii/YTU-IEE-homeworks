class Basket:
    def __init__(self,basketID):
        self.basketID=basketID
        self.items=[]
    
    def addItem(self,item):
        if item.count <= 0:
            print("Ürün stokta yok.")
            return
        if len(self.items) >= 3:
            print("Sepetiniz dolu.Maksimum ürün sayısına ulaşıldı.")
            return
        self.items.append(item)
        print("Ürün sepetinize başarıyla eklendi.")

    def basketInfo(self):
        if not self.items:
            print("Sepetiniz boş.Öncelikle ürün ekleyinz.")
            
        else:
            for i,item in enumerate(self.items, start=1):
                print(f"{i}. ürünün barkodu:{item.barcodeNo}, ürünün ismi:{item.itemName}, fiyatı:{item.price}, stok durumu:{item.count} ")
    
    def calculateTotalPrice(self):
        Totalprice=0
        for item in self.items:
            Totalprice+=item.price
        return Totalprice            