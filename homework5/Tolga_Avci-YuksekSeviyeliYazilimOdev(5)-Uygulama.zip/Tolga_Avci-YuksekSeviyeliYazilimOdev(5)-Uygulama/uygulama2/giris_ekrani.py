from PyQt5.QtWidgets import *
from giris_ekrani_python import Ui_Form
from ana_ekran import MainWindow

class LoginPage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.label_hatamesaji.setVisible(False)
        self.ui.pushButton_giris.clicked.connect(self.kontrolEt)
    def kontrolEt(self):
        kadi = self.ui.lineEdit_kadi.text()
        sifre = self.ui.lineEdit_sifre.text()
        if(kadi == "tolga" and sifre == "123"):
            self.close()
            self.main = MainWindow()
            self.main.show()
        else:
            self.ui.label_hatamesaji.setVisible(True)
                
