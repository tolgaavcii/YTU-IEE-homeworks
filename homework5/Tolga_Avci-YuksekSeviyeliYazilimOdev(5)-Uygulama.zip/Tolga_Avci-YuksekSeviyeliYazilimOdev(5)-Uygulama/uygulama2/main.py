from PyQt5.QtWidgets import QApplication
from giris_ekrani import LoginPage
from ana_ekran import MainWindow



app = QApplication([])
pencere = LoginPage()
pencere.show()
app.exec_()