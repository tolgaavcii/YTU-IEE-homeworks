from PyQt5.QtWidgets import *
from ana_ekran_python import Ui_MainWindow
from PyQt5.QtCore import QTimer
import cv2 as cv
from PyQt5.QtGui import QImage, QPixmap
import random


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.saniye = 0
        self.timer_zaman = QTimer(self)
        self.timer_zaman.timeout.connect(self.zamanGuncelle)
        self.timer_zaman.start(1000)
        font = self.ui.label_zaman.font()
        font.setPointSize(16)
        font.setBold(True)
        self.ui.label_zaman.setFont(font)
        
        self.timer_cam = QTimer(self)
        self.timer_cam.timeout.connect(self.goruntuGuncelle)
        self.cap = None
        self.ui.pushButton_start_cam.clicked.connect(self.baslatKamera)
        self.ui.pushButton_stop_cam.clicked.connect(self.durdurKamera)

        self.timer_values = QTimer(self)
        self.timer_values.timeout.connect(self.Sicaklik)
        self.timer_values.timeout.connect(self.Basinc)
        self.timer_values.timeout.connect(self.Yukseklik)
        self.timer_values.start(1000)
        

    def zamanGuncelle(self):
        self.saniye += 1
        dakika = self.saniye // 60
        saniye = self.saniye % 60
        self.ui.label_zaman.setText(f"{dakika:02d}:{saniye:02d}")
    
    
    
    
    
    def baslatKamera(self):
        self.cap = cv.VideoCapture(0)
        self.timer_cam.start(30)
    
    
    
    def goruntuGuncelle(self):
        ret, frame = self.cap.read()
        if ret:
            frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
            h, w, ch = frame.shape
            bytes_per_line = ch * w
            qimg = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            self.ui.label_cam.setPixmap(QPixmap.fromImage(qimg))



    def durdurKamera(self):
        self.timer_cam.stop()
        if self.cap is not None:    
            self.cap.release()
            self.cap = None
        self.ui.label_cam.clear()

    
    def Sicaklik(self):
        sicaklik = random.uniform(10,38)
        self.ui.pushButton_sicaklik.setText(f"{sicaklik:.2f}C")
    
    def Basinc(self):
        basinc = random.randint(94000,96000)   
        self.ui.pushButton_basinc.setText(f"{basinc}Pa") 
    
    def Yukseklik(self):
        yukseklik = random.randint(0,500)
        self.ui.pushButton_yukseklik.setText(f"{yukseklik}m")