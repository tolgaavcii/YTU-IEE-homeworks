import socket

HOST = "127.0.0.1"
PORT = 12345

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Sunucuya bağlandın.(çıkmak için 'exit' yaz)")

while True:
    mesaj = input("Sen: ")
    client.send(mesaj.encode("utf-8"))

    if mesaj.lower() in ["exit", "quit", "çıkış"]:
        print("Sohbet sonlandırıldı.")
        break

    cevap = client.recv(1024).decode("utf-8")
    print("Bot:", cevap)

client.close()
