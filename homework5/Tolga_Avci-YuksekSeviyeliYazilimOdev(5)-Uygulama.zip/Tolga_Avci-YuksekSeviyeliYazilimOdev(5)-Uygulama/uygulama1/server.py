import socket
import json
import random

HOST = "127.0.0.1"
PORT = 12345

with open("cevaplar.json", "r", encoding="utf-8") as f:
    cevaplar = json.load(f)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(1)

print(f"Sunucu {HOST}:{PORT} adresinde dinliyor...")

while True:
    conn, addr = server.accept()
    print("Bağlantı kuruldu:", addr)

    while True:
        data = conn.recv(1024).decode("utf-8")
        if not data:
            break

        if data.lower() in ["exit", "quit", "çıkış"]:
            print("İstemci sohbeti kapattı.")
            break

        print("İstemciden gelen:", data)

        if data.lower() in cevaplar:
            cevap = random.choice(cevaplar[data.lower()])
        else:
            cevap = "Bu konuda bir cevabım yok."

        conn.send(cevap.encode("utf-8"))

    conn.close()
